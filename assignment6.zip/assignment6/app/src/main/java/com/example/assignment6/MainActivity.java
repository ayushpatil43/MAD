package com.example.assignment6;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button btnSubmit;
    CheckBox checkBox;
    RadioGroup radioGroup;
    ToggleButton toggleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        btnSubmit = findViewById(R.id.btnSubmit);
        checkBox = findViewById(R.id.checkBox);
        radioGroup = findViewById(R.id.radioGroup);
        toggleButton = findViewById(R.id.toggleButton);

        // Button Click
        btnSubmit.setOnClickListener(v -> {

            String name = editText.getText().toString();

            if (name.isEmpty()) {
                Toast.makeText(this, "Enter your name", Toast.LENGTH_SHORT).show();
                return;
            }

            // CheckBox
            String checkStatus = checkBox.isChecked() ? "Subscribed" : "Not Subscribed";

            // RadioButton
            int selectedId = radioGroup.getCheckedRadioButtonId();
            RadioButton radio = findViewById(selectedId);
            String gender = (radio != null) ? radio.getText().toString() : "Not Selected";

            // ToggleButton
            String toggleStatus = toggleButton.isChecked() ? "ON" : "OFF";

            String result = "Name: " + name +
                    "\nGender: " + gender +
                    "\nCheckbox: " + checkStatus +
                    "\nToggle: " + toggleStatus;

            Toast.makeText(this, result, Toast.LENGTH_LONG).show();
        });

        // CheckBox Event
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked)
                Toast.makeText(this, "Checkbox Checked", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Checkbox Unchecked", Toast.LENGTH_SHORT).show();
        });

        // Toggle Event
        toggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked)
                Toast.makeText(this, "Toggle ON", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Toggle OFF", Toast.LENGTH_SHORT).show();
        });

        // RadioGroup Event
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            if (rb != null) {
                Toast.makeText(this, "Selected: " + rb.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}