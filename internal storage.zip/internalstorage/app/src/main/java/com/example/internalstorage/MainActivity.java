package com.example.internalstorage;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private EditText editTextData;
    private TextView textViewOutput;
    private Button btnSave, btnRead;
    private final String FILE_NAME = "mydata.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextData = findViewById(R.id.editTextData);
        textViewOutput = findViewById(R.id.textViewOutput);
        btnSave = findViewById(R.id.btnSave);
        btnRead = findViewById(R.id.btnRead);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readData();
            }
        });
    }

    private void saveData() {
        String text = editTextData.getText().toString();
        try {
            // openFileOutput returns an instance of FileOutputStream
            // Using MODE_PRIVATE as suggested by modern Android standards
            FileOutputStream fOut = openFileOutput(FILE_NAME, MODE_PRIVATE);
            fOut.write(text.getBytes());
            fOut.close();

            Toast.makeText(getBaseContext(), "File saved successfully!", Toast.LENGTH_SHORT).show();
            editTextData.setText("");
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getBaseContext(), "Error saving file", Toast.LENGTH_SHORT).show();
        }
    }

    private void readData() {
        try {
            FileInputStream fIn = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fIn);
            char[] inputBuffer = new char[100];
            StringBuilder s = new StringBuilder();
            int charRead;

            while ((charRead = isr.read(inputBuffer)) > 0) {
                // char to string conversion
                String readstring = String.copyValueOf(inputBuffer, 0, charRead);
                s.append(readstring);
            }
            isr.close();
            textViewOutput.setText(s.toString());
            Toast.makeText(getBaseContext(), "File read successfully!", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getBaseContext(), "Error reading file", Toast.LENGTH_SHORT).show();
        }
    }
}
