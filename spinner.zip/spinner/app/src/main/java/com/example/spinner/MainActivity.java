package com.example.spinner;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    Button btnAlert, btnPopup, btnToast;

    String[] items = {"Select", "Apple", "Banana", "Mango", "Orange"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        btnAlert = findViewById(R.id.btnAlert);
        btnPopup = findViewById(R.id.btnPopup);
        btnToast = findViewById(R.id.btnToast);

        // Spinner setup
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                items
        );
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    Toast.makeText(MainActivity.this,
                            "Selected: " + items[position],
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Alert Dialog button
        btnAlert.setOnClickListener(v -> showAlertDialog());

        // Popup Menu button
        btnPopup.setOnClickListener(v -> showPopupMenu(v));

        // Toast button
        btnToast.setOnClickListener(v ->
                Toast.makeText(MainActivity.this,
                        "This is a Toast message",
                        Toast.LENGTH_LONG).show());
    }

    // Alert Dialog
    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation")
                .setMessage("Do you want to continue?")
                .setPositiveButton("Yes", (dialog, which) ->
                        Toast.makeText(this, "Clicked Yes", Toast.LENGTH_SHORT).show())
                .setNegativeButton("No", (dialog, which) ->
                        Toast.makeText(this, "Clicked No", Toast.LENGTH_SHORT).show())
                .setNeutralButton("Cancel", (dialog, which) ->
                        Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show());

        builder.show();
    }

    // Popup Menu
    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.item1) {
                Toast.makeText(this, "Option 1 clicked", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.item2) {
                Toast.makeText(this, "Option 2 clicked", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.item3) {
                Toast.makeText(this, "Option 3 clicked", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        popup.show();
    }
}